<?php
  // this is a little Welcome area that you might like to customize. 


 
?>
<h1 class="display-4">
  Welcome, <?= App::User()->FullName ?>
</h1> 