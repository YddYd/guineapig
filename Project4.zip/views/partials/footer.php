  <!-- Bootstrap JavaScript Bundle with Popper. See Also:
  https://getbootstrap.com/docs/5.1/getting-started/introduction/ -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
  <footer>
    <div class="container">
         Created with <a href="https://v5.getbootstrap.com/">Bootstrap</a>, <a href="https://v3.vuejs.org/">VueJS</a>, <a href="https://www.php.net/">PHP</a>, and <a href="https://www.mysql.com/">MySQL</a> by <a  href="https://www.nsitu.ca">Harold Sikkema</a>.
         Modify by <a href="https://ixd0277.phoenix.sheridanc.on.ca/Portfolio/index.html">Ding</a> .
         Background available from <a href="https://unsplash.com/photos/0EhFkzIinlk">Dan</a> .
       </div>
  </footer>
  </body>
</html>
<?php exit; ?>